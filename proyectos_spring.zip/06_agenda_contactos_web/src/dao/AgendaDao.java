package dao;

import java.util.List;

import model.Contactos;

public interface AgendaDao {

	boolean A�adirContacto(Contactos contacto);

	Contactos BuscarContacto(String email);

	void EliminarContacto(String email);

	List<Contactos> devolverContactos();

}