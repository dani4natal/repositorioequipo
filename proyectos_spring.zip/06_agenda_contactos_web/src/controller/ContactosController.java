package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import dao.AgendaDao;
import model.Contactos;

@Controller
public class ContactosController {
	@Autowired
	AgendaDao agendasDao;
	
	@GetMapping(value="/mostrarContactos")
	public String mostrarPeliculas(HttpServletRequest request) {
		List <Contactos> resultado=agendasDao.devolverContactos();
		request.setAttribute("Contactos", resultado);
		return "Contactos";
	}
	
	@PostMapping(value="/nuevoContacto")
	public String registro(@RequestParam("nombre") String nombre, 
			@RequestParam("email") String email, 
			@RequestParam("edad") int edad) {
		Contactos contacto = new Contactos(nombre, email, edad);
		agendasDao.A�adirContacto(contacto);
		return "Inicio";
	}
	
	@PostMapping(value="/eliminarContacto")
	public String registro(@RequestParam("email") String email) {
		agendasDao.EliminarContacto(email);
		return "Inicio";
	}
	
}


