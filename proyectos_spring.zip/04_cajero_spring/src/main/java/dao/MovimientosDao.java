package dao;

import java.util.List;

import model.Movimiento;

public interface MovimientosDao {
		List<Movimiento> obtenerMovimientos(int idCuenta);
		void crearMovimiento(Movimiento movimiento);
}
