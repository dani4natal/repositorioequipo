package dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import model.Cuenta;

@Repository("cuentasDao")

public class CuentasImpl implements CuentasDao {
	@Autowired
	JdbcTemplate template;
	@Override
	public Cuenta obtenerCuenta(int numeroCuenta) {
		String sql="select * from cuentas where numeroCuenta =?";
		List <Cuenta> cuentas= template.query(sql, (rs,f)->rs.isAfterLast()?null:new Cuenta(rs.getInt("numeroCuenta"), rs.getDouble("saldo"), rs.getString("Tipocuenta")), numeroCuenta);
		return cuentas.size()>0?cuentas.get(0):null;
	}

	@Override
	public void actualizarCuenta(Cuenta cuenta) {
		String sql= "UPDATE Cuentas SET Saldo = ? WHERE numeroCuenta= ?";
		template.update(sql, cuenta.getSaldo(), cuenta.getNumeroCuenta());
	}
	

}
