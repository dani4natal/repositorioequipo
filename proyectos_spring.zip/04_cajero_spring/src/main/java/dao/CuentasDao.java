package dao;

import model.Cuenta;

public interface CuentasDao {
		Cuenta obtenerCuenta(int numeroCuenta);
		void actualizarCuenta(Cuenta cuenta);
}
