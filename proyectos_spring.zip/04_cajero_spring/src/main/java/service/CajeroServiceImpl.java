package service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import dao.CuentasDao;
import dao.MovimientosDao;
import model.Cuenta;
import model.Movimiento;


@Service("cajeroService")
public class CajeroServiceImpl implements CajeroService {
	@Autowired
	@Qualifier("cuentasDao")
	CuentasDao cuentasDao;
	@Autowired
	MovimientosDao movimientosDao;

	@Override
	public Cuenta buscarCuenta(int numeroCuenta) {
		// TODO Auto-generated method stub
		return cuentasDao.obtenerCuenta(numeroCuenta);
	}

	@Override
	public double obtenerSaldo(int numeroCuenta) {
		// TODO Auto-generated method stub
		Cuenta cuenta=buscarCuenta(numeroCuenta);
		return cuenta.getSaldo();
	}

	@Override
	public List<Movimiento> obtenerMovimientos(int numeroCuenta) {
		// TODO Auto-generated method stub
		Cuenta cuenta=buscarCuenta(numeroCuenta);
		return movimientosDao.obtenerMovimientos(cuenta.getNumeroCuenta());
	}

	@Override
	public void ingresar(int numeroCuenta, double cantidad) {
		// TODO Auto-generated method stub
		Cuenta cuenta=buscarCuenta(numeroCuenta);
		cuenta.setSaldo(cuenta.getSaldo()+cantidad);
		cuentasDao.actualizarCuenta(cuenta);
		Movimiento movimiento=new Movimiento(0,cantidad,numeroCuenta, new Date(), "ingreso");
		movimientosDao.crearMovimiento(movimiento);

	}

	@Override
	public void extraccion(int numeroCuenta, double cantidad) {
		// TODO Auto-generated method stub
		Cuenta cuenta=buscarCuenta(numeroCuenta);
		cuenta.setSaldo(cuenta.getSaldo()-cantidad);
		cuentasDao.actualizarCuenta(cuenta);
		Movimiento movimiento=new Movimiento(0,cantidad,numeroCuenta, new Date(), "extracción");
		movimientosDao.crearMovimiento(movimiento);

	}

}
