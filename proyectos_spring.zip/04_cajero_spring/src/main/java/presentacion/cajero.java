package presentacion;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Cuenta;
import model.Movimiento;
import service.CajeroService;

public class cajero {
	
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		BeanFactory factory= new ClassPathXmlApplicationContext("springConfig.xml");
		CajeroService cajeros= factory.getBean(CajeroService.class);
		System.out.println("Introduce tu número de cuenta");
		int a=Integer.parseInt(sc.nextLine());
		Cuenta cuenta1=cajeros.buscarCuenta(a);
		if(cuenta1==null) {
			System.out.println("Número de cuenta no existente");
			return;
		}
		else {
			System.out.println("Introduce la operación a realizar");
			generarMenu();
			int b=Integer.parseInt(sc.nextLine());
			switch(b) {
			case 1:
				System.out.println("Introduce cantidad a ingresar");
				double cantidad= Double.parseDouble(sc.nextLine());
				cajeros.ingresar(a, cantidad);
				break;
			case 2:
				System.out.println("Introduce cantidad a extraer");
				double cantidad2= Double.parseDouble(sc.nextLine());
				cajeros.extraccion(a, cantidad2);
				break;
			case 3:
				MostrarMovimientos(cajeros.obtenerMovimientos(a));
				System.out.println("Saldo: " +cajeros.obtenerSaldo(a));
				break;
			case 4:
				break;
			default:
				System.out.println("Debes escribir una opción válida");
			}
			
		}
		}
	public static void generarMenu() {
		System.out.println("1----Ingresar");
		System.out.println("2----Extraer");
		System.out.println("3----Movimientos y saldo");
		System.out.println("4----Salir");
	}
	public static void MostrarMovimientos(List <Movimiento> movimientos) {
		movimientos.forEach(mov->System.out.println(mov.getIdMovimiento()+"-"+mov.getCantidad()+"-"+mov.getIdCuenta()+"-"+mov.getFecha()+"-"+mov.getOperacion()));
	}

}
