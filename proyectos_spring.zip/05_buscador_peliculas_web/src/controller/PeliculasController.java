package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import model.Pelicula;


@Controller
public class PeliculasController {
	List<Pelicula> peliculas = new ArrayList<>();
	public PeliculasController(){
		peliculas.add(new Pelicula("pelicula 1", "drama", 150));
		peliculas.add(new Pelicula("pelicula 2", "terror", 125));
		peliculas.add(new Pelicula("pelicula 3", "terror", 90));
		peliculas.add(new Pelicula("pelicula 4", "drama", 130));
		peliculas.add(new Pelicula("pelicula 5", "comedia", 100));
		peliculas.add(new Pelicula("pelicula 6", "drama", 98));
	}
	
	
	
	@PostMapping(value="/verPeliculas")
	public String recuperarPeliculas(@RequestParam("tematica") String tematica, HttpServletRequest request) {
		List <Pelicula> resultado=peliculas.stream()
				.filter(p->p.getTematica().equals(tematica))
				.collect(Collectors.toList());
		//guardamos la lista de peliculas en un atributo de petici�n
		//para que sea recogido por la vista y pueda generar una respuesta
		request.setAttribute("peliculas", resultado);
		//devolvemos la dir de la pagina(vista) encargada de generar la respuesta
		return "peliculas";
	}
	
	@GetMapping(value="/mostrarPeliculas")
	public String mostrarPeliculas(HttpServletRequest request) {
		List <Pelicula> resultado=peliculas.stream()
				.collect(Collectors.toList());
		//guardamos la lista de peliculas en un atributo de petici�n
		//para que sea recogido por la vista y pueda generar una respuesta
		request.setAttribute("peliculas", resultado);
		//devolvemos la dir de la pagina(vista) encargada de generar la respuesta
		return "peliculas";
	}
}
