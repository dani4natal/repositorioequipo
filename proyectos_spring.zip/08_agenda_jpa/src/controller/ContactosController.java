package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import dao.AgendaDao;
import model.Contacto;

@Controller
public class ContactosController {
	@Autowired
	AgendaDao agendasDao;
	
	@RequestMapping(value="/mostrarContactos")
	public String mostrarPeliculas(HttpServletRequest request) {
		List <Contacto> resultado=agendasDao.devolverContactos();
		request.setAttribute("Contactos", resultado);
		return "Contactos";
	}
	
	@PostMapping(value="/nuevoContacto")
	public String registro(@RequestParam("nombre") String nombre, 
			@RequestParam("email") String email, 
			@RequestParam("edad") int edad) {
		Contacto contacto = new Contacto(0, edad, email,nombre);
		agendasDao.A�adirContacto(contacto);
		return "Inicio";
	}
	
	@PostMapping(value="/eliminarContacto")
	public String eliminarContacto(@RequestParam("email") String email) {
		agendasDao.EliminarContacto(email);
		return "Inicio";
	}
	@GetMapping(value="/eliminarPorId")
	public String eliminarPorId(@RequestParam("idContacto") int idContacto) {
		agendasDao.EliminarContacto(idContacto);
		return "forward:/mostrarContactos";
	}
}


