package dao;

import java.util.List;

import model.Contacto;

public interface AgendaDao {

	boolean A�adirContacto(Contacto contacto);

	Contacto BuscarContacto(String email);

	void EliminarContacto(String email);

	List<Contacto> devolverContactos();
	
	void EliminarContacto(int idContacto);

}