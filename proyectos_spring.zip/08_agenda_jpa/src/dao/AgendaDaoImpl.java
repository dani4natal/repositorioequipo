package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import model.Contacto;

@Repository("agendaService")

public class AgendaDaoImpl implements AgendaDao {
	
	@PersistenceContext
	EntityManager em;

	@Override
	public boolean A�adirContacto(Contacto contacto) {
		em.persist(contacto);
		return true;
	}

	@Override
	public Contacto BuscarContacto(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void EliminarContacto(String email) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Contacto> devolverContactos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void EliminarContacto(int idContacto) {
		// TODO Auto-generated method stub
		Contacto contacto=em.find(Contacto.class, idContacto);
		if(contacto!=null) {
			em.remove(contacto);
		}
	}
	
}

