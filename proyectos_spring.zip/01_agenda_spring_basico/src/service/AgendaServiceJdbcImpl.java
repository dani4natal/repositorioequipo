package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.Contactos;

@Service("agendaService")

public class AgendaServiceJdbcImpl implements AgendaService {
	//inyecci�n de dependencia
	@Autowired
	DataSource dataSource;
	@Override
	public boolean A�adirContacto(Contactos contacto) {
		// TODO Auto-generated method stub
		String sql="Insert into contactos(nombre,email,edad) values(?,?,?)";
		try(Connection con=dataSource.getConnection();
				PreparedStatement pst= con.prepareStatement(sql);) {
			pst.setString(1, contacto.getNombre());
			pst.setString(2, contacto.getEmail());
			pst.setInt(3, contacto.getEdad());
			pst.execute();//sin sql se la has dado en la creacion
			return true;
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	@Override
	public Contactos BuscarContacto(String email) {
		String sql="select * from contactos where email =?";
		Contactos contactoRecuperado= null;
		try(Connection con=dataSource.getConnection();
				Statement st= con.createStatement();) {
			ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				String p=rs.getString("nombre");
				int m=rs.getInt("edad");
				contactoRecuperado=new Contactos(p,email,m);
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return contactoRecuperado;
	}

	@Override
	public void EliminarContacto(String email) {
		String sql="delete from contactos where email =" +email;
		try(Connection con=dataSource.getConnection();
				Statement st= con.createStatement();
				) {
			st.execute(sql);
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public List<Contactos> devolverContactos() {
		String sql="select * from contactos";
		List<Contactos> contactosTotales = new ArrayList<>();
		try(Connection con=dataSource.getConnection();
				Statement st= con.createStatement();) {
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				contactosTotales.add(new Contactos(rs.getString("nombre"),rs.getString("email"),rs.getInt("edad")));
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		return contactosTotales;
	}

}
