package presentacion;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import model.Contactos;
import service.AgendaService;

public class Agenda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		BeanFactory factory= new ClassPathXmlApplicationContext("springConfig.xml");
		AgendaService gestor= factory.getBean(AgendaService.class);
		// AgendaService gestor= (AgendaService) factory.getBean("AgendaService");
		int a=Integer.parseInt(sc.nextLine());
		switch(a) {
		case 1:
			System.out.println("Introduce nombre"); 
			String nomb= sc.nextLine();
			System.out.println("Introduce email"); 
			String email= sc.nextLine();
			System.out.println("Introduce edad"); 
			int edad=Integer.parseInt(sc.nextLine());
		    if(gestor.A�adirContacto(new Contactos(nomb,email,edad))) {
		    	System.out.println("Contacto a�adido");}
		    else {
		    	System.out.println("El email esta repetido");
		    }
		    break;
		case 2:
			System.out.println("Introduce email"); 
			email= sc.nextLine();
			Contactos c=gestor.BuscarContacto(email);
			 if(c==null){
                 System.out.println("No se encontr� el contacto");  
              }
              else{
                 System.out.println(c.getNombre()+"-"+c.getEmail()+"-"+c.getEdad());   
              }
             break;
		case 3:
			System.out.println("Introduce email"); 
			 email= sc.nextLine();
			gestor.EliminarContacto(email);
			break;
	      case 4:           	   
              mostrarContactos(gestor.devolverContactos());                  
              break;
          case 5:
              break;
          default:
              System.out.println("debes escribir una opci�n v�lida");
      }//fin switch
	}

	public static void mostrarContactos(List <Contactos> contactos) {
		contactos.forEach(con->System.out.println(con.getNombre()+"-"+con.getEmail()+"-"+con.getEdad()));
        }
	}

