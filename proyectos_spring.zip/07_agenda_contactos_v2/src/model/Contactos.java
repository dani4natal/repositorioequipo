package model;
//generalmente a este tipo de paquetes se le llama movil
public class Contactos {
	private String nombre;
	private String email;
	private int edad;
	private int idContacto;
	public Contactos(String nombre, String email, int edad, int idContacto) {
		super();
		this.nombre = nombre;
		this.email = email;
		this.edad = edad;
		this.idContacto = idContacto;
	}
	public Contactos(String nombre, String email, int edad) {
		super();
		this.nombre = nombre;
		this.email = email;
		this.edad = edad;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public int getIdContacto() {
		return idContacto;
	}
	public void setIdContacto(int idContacto) {
		this.idContacto = idContacto;
	}
	
	
	
}

