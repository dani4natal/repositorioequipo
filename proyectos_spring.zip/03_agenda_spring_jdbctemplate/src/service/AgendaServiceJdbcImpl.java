package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import model.Contactos;

@Service("agendaService")

public class AgendaServiceJdbcImpl implements AgendaService {
	//inyecci�n de dependencia
	@Autowired
	JdbcTemplate template;
	@Override
	public boolean A�adirContacto(Contactos contacto) {
		// TODO Auto-generated method stub
		String sql="Insert into contactos(nombre,email,edad) values(?,?,?)";
		int cantidad= template.update(sql, contacto.getNombre(),contacto.getEmail(),contacto.getEdad());
		return cantidad>0?true:false;
	}

	@Override
	public Contactos BuscarContacto(String email) {
		String sql="select * from contactos where email =?";
		List <Contactos> contactos=template.query(sql, (rs,f)->rs.isAfterLast()?null:new Contactos(rs.getString("nombre"), rs.getString("email"), rs.getInt("edad")), email);
		return contactos.size()>0?contactos.get(0):null;
	}

	@Override
	public void EliminarContacto(String email) {
		String sql="delete from contactos where email = ?" ;
		template.update(sql, email);
	}

	@Override
	public List<Contactos> devolverContactos() {
		String sql="select * from contactos";
		return template.query(sql, (rs,f)->new Contactos(rs.getString("nombre"), rs.getString("email"), rs.getInt("edad")));
	}
}

